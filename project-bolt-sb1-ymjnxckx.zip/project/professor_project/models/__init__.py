"""
Models package initialization.
"""