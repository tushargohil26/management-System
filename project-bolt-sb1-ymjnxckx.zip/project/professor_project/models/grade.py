"""
Grade Model
Represents a grade for a student in a specific course.
"""

from typing import Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class Grade:
    """Grade data model."""
    student_id: int
    course_id: int
    value: float  # Numeric grade value (e.g., 85.5)
    comments: Optional[str] = None
    id: Optional[int] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    
    def get_letter_grade(self) -> str:
        """Convert numeric grade to letter grade."""
        if self.value >= 90:
            return "A"
        elif self.value >= 80:
            return "B"
        elif self.value >= 70:
            return "C"
        elif self.value >= 60:
            return "D"
        else:
            return "F"
    
    def is_passing(self) -> bool:
        """Check if the grade is passing (>= 60)."""
        return self.value >= 60
    
    def __str__(self) -> str:
        return f"Grade: {self.value} ({self.get_letter_grade()})"