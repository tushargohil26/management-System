"""
Student Model
Represents a student in the academic system.
"""

from typing import List, Optional, Dict
from dataclasses import dataclass, field

@dataclass
class Student:
    """Student data model."""
    first_name: str
    last_name: str
    student_id: str  # e.g., "S12345"
    email: str
    major: str
    year: int  # 1 = Freshman, 2 = Sophomore, etc.
    id: Optional[int] = None
    courses: List["Course"] = field(default_factory=list)
    
    @property
    def full_name(self) -> str:
        """Return the student's full name."""
        return f"{self.first_name} {self.last_name}"
    
    def add_course(self, course: "Course") -> None:
        """Enroll in a course."""
        if course not in self.courses:
            self.courses.append(course)
    
    def remove_course(self, course: "Course") -> None:
        """Drop a course."""
        if course in self.courses:
            self.courses.remove(course)
    
    def get_grades(self) -> Dict["Course", float]:
        """Get the student's grades for all courses."""
        from controllers.grade_controller import GradeController
        
        grade_controller = GradeController()
        grades = {}
        
        for course in self.courses:
            grade = grade_controller.get_grade(student_id=self.id, course_id=course.id)
            if grade:
                grades[course] = grade.value
        
        return grades
    
    def get_gpa(self) -> float:
        """Calculate the student's GPA."""
        grades = self.get_grades()
        
        if not grades:
            return 0.0
        
        # Simple GPA calculation (assuming 4.0 scale)
        grade_points = {
            90: 4.0,  # A
            80: 3.0,  # B
            70: 2.0,  # C
            60: 1.0,  # D
            0: 0.0    # F
        }
        
        total_points = 0
        for course, grade in grades.items():
            for threshold, points in sorted(grade_points.items(), reverse=True):
                if grade >= threshold:
                    total_points += points * course.credits
                    break
        
        total_credits = sum(course.credits for course in grades.keys())
        return total_points / total_credits if total_credits > 0 else 0.0
    
    def __str__(self) -> str:
        return f"Student {self.full_name} ({self.student_id})"