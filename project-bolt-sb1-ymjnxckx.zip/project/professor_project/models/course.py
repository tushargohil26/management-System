"""
Course Model
Represents an academic course in the system.
"""

from typing import List, Optional, Dict, Any
from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class Course:
    """Course data model."""
    code: str  # e.g., CS101
    title: str
    description: str
    credits: int
    semester: str  # e.g., "Fall 2023"
    id: Optional[int] = None
    professor_id: Optional[int] = None
    professor: Optional["Professor"] = None
    students: List["Student"] = field(default_factory=list)
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    
    def add_student(self, student: "Student") -> None:
        """Enroll a student in the course."""
        if student not in self.students:
            self.students.append(student)
            student.add_course(self)
    
    def remove_student(self, student: "Student") -> None:
        """Remove a student from the course."""
        if student in self.students:
            self.students.remove(student)
            student.remove_course(self)
    
    def get_grade_statistics(self) -> Dict[str, Any]:
        """Calculate grade statistics for the course."""
        from controllers.grade_controller import GradeController
        
        grade_controller = GradeController()
        grades = grade_controller.get_grades_for_course(self.id)
        
        if not grades:
            return {
                "average": None,
                "median": None,
                "highest": None,
                "lowest": None,
                "passing_rate": None
            }
        
        values = [grade.value for grade in grades]
        passing = sum(1 for v in values if v >= 60)  # Assuming 60 is passing
        
        return {
            "average": sum(values) / len(values),
            "median": sorted(values)[len(values) // 2],
            "highest": max(values),
            "lowest": min(values),
            "passing_rate": passing / len(values) * 100
        }
    
    def __str__(self) -> str:
        return f"{self.code}: {self.title} ({self.semester})"