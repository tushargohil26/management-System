"""
Professor Model
Represents a professor in the academic system.
"""

from typing import List, Optional
from dataclasses import dataclass, field

@dataclass
class Professor:
    """Professor data model."""
    first_name: str
    last_name: str
    department: str
    email: str
    office: str
    phone: Optional[str] = None
    id: Optional[int] = None
    courses: List["Course"] = field(default_factory=list)
    
    @property
    def full_name(self) -> str:
        """Return the professor's full name."""
        return f"{self.first_name} {self.last_name}"
    
    def add_course(self, course: "Course") -> None:
        """Add a course to the professor's teaching load."""
        if course not in self.courses:
            self.courses.append(course)
            course.professor = self
    
    def remove_course(self, course: "Course") -> None:
        """Remove a course from the professor's teaching load."""
        if course in self.courses:
            self.courses.remove(course)
            course.professor = None
    
    def get_student_count(self) -> int:
        """Get the total number of students across all courses."""
        return sum(len(course.students) for course in self.courses)
    
    def __str__(self) -> str:
        return f"Professor {self.full_name} ({self.department})"