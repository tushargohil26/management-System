"""
Tests for the Course model and controller.
"""

import unittest
from models.course import Course
from controllers.course_controller import CourseController
from models.professor import Professor
from models.student import Student

class TestCourse(unittest.TestCase):
    """Test cases for the Course model."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.course = Course(
            code="TEST101",
            title="Test Course",
            description="A test course",
            credits=3,
            semester="Test Semester"
        )
    
    def test_string_representation(self):
        """Test the string representation of a Course."""
        self.assertEqual(str(self.course), "TEST101: Test Course (Test Semester)")
    
    def test_add_student(self):
        """Test adding a student to a course."""
        student = Student(
            first_name="Test",
            last_name="Student",
            student_id="TS001",
            email="student@example.com",
            major="Test Major",
            year=2
        )
        
        self.course.add_student(student)
        
        self.assertIn(student, self.course.students)
        self.assertIn(self.course, student.courses)
    
    def test_remove_student(self):
        """Test removing a student from a course."""
        student = Student(
            first_name="Test",
            last_name="Student",
            student_id="TS001",
            email="student@example.com",
            major="Test Major",
            year=2
        )
        
        self.course.add_student(student)
        self.course.remove_student(student)
        
        self.assertNotIn(student, self.course.students)
        self.assertNotIn(self.course, student.courses)

class TestCourseController(unittest.TestCase):
    """Test cases for the CourseController."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.controller = CourseController()
        
        # Clear any sample data
        self.controller.courses = []
        self.controller.next_id = 1
        
        # Add a test course
        self.test_course = Course(
            code="TEST101",
            title="Test Course",
            description="A test course",
            credits=3,
            semester="Test Semester"
        )
        
        self.controller.add_course(self.test_course)
    
    def test_add_course(self):
        """Test adding a course."""
        new_course = Course(
            code="TEST102",
            title="Another Test Course",
            description="Another test course",
            credits=4,
            semester="Test Semester"
        )
        
        result = self.controller.add_course(new_course)
        
        self.assertTrue(result)
        self.assertEqual(len(self.controller.courses), 2)
        self.assertEqual(new_course.id, 2)
    
    def test_get_course_by_id(self):
        """Test getting a course by ID."""
        course = self.controller.get_course_by_id(1)
        
        self.assertIsNotNone(course)
        self.assertEqual(course.code, "TEST101")
        self.assertEqual(course.title, "Test Course")
    
    def test_update_course(self):
        """Test updating a course."""
        course = self.controller.get_course_by_id(1)
        
        updated_course = Course(
            id=course.id,
            code=course.code,
            title="Updated Course Title",
            description=course.description,
            credits=course.credits,
            semester=course.semester
        )
        
        result = self.controller.update_course(updated_course)
        
        self.assertTrue(result)
        
        # Get the updated course
        updated = self.controller.get_course_by_id(1)
        self.assertEqual(updated.title, "Updated Course Title")
    
    def test_delete_course(self):
        """Test deleting a course."""
        result = self.controller.delete_course(1)
        
        self.assertTrue(result)
        self.assertEqual(len(self.controller.courses), 0)
    
    def test_assign_professor(self):
        """Test assigning a professor to a course."""
        professor = Professor(
            first_name="Test",
            last_name="Professor",
            department="Test Department",
            email="test@example.com",
            phone="555-123-4567",
            office="Test Building 101"
        )
        
        result = self.controller.assign_professor(1, professor)
        
        self.assertTrue(result)
        
        course = self.controller.get_course_by_id(1)
        self.assertEqual(course.professor, professor)
        self.assertIn(course, professor.courses)
    
    def test_get_courses_by_semester(self):
        """Test getting courses by semester."""
        # Add another course in a different semester
        another_course = Course(
            code="TEST103",
            title="Different Semester Course",
            description="A course in a different semester",
            credits=3,
            semester="Different Semester"
        )
        
        self.controller.add_course(another_course)
        
        # Get courses for the test semester
        results = self.controller.get_courses_by_semester("Test Semester")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].code, "TEST101")
        
        # Get courses for the different semester
        results = self.controller.get_courses_by_semester("Different Semester")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].code, "TEST103")
    
    def test_search_courses(self):
        """Test searching for courses."""
        # Add another course for testing search
        another_course = Course(
            code="SEARCH200",
            title="Searchable Course",
            description="A course that can be found by search",
            credits=3,
            semester="Test Semester"
        )
        
        self.controller.add_course(another_course)
        
        # Search by code
        results = self.controller.search_courses("TEST")
        self.assertEqual(len(results), 1)
        
        # Search by title
        results = self.controller.search_courses("search")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].code, "SEARCH200")
        
        # Search with no matches
        results = self.controller.search_courses("nonexistent")
        self.assertEqual(len(results), 0)

if __name__ == '__main__':
    unittest.main()