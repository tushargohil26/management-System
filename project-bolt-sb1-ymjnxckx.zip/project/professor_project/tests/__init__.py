"""
Tests package initialization.
"""