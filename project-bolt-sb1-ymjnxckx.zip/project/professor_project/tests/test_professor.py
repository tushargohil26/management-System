"""
Tests for the Professor model and controller.
"""

import unittest
from models.professor import Professor
from controllers.professor_controller import ProfessorController

class TestProfessor(unittest.TestCase):
    """Test cases for the Professor model."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.professor = Professor(
            first_name="Test",
            last_name="Professor",
            department="Test Department",
            email="test@example.com",
            phone="555-123-4567",
            office="Test Building 101"
        )
    
    def test_full_name(self):
        """Test that full_name property returns the correct value."""
        self.assertEqual(self.professor.full_name, "Test Professor")
    
    def test_string_representation(self):
        """Test the string representation of a Professor."""
        self.assertEqual(str(self.professor), "Professor Test Professor (Test Department)")
    
    def test_add_course(self):
        """Test adding a course to a professor."""
        from models.course import Course
        
        course = Course(
            code="TEST101",
            title="Test Course",
            description="A test course",
            credits=3,
            semester="Test Semester"
        )
        
        self.professor.add_course(course)
        
        self.assertIn(course, self.professor.courses)
        self.assertEqual(course.professor, self.professor)
    
    def test_remove_course(self):
        """Test removing a course from a professor."""
        from models.course import Course
        
        course = Course(
            code="TEST101",
            title="Test Course",
            description="A test course",
            credits=3,
            semester="Test Semester"
        )
        
        self.professor.add_course(course)
        self.professor.remove_course(course)
        
        self.assertNotIn(course, self.professor.courses)
        self.assertIsNone(course.professor)
    
    def test_get_student_count(self):
        """Test getting the total student count across all courses."""
        from models.course import Course
        from models.student import Student
        
        course1 = Course(
            code="TEST101",
            title="Test Course 1",
            description="A test course",
            credits=3,
            semester="Test Semester"
        )
        
        course2 = Course(
            code="TEST102",
            title="Test Course 2",
            description="Another test course",
            credits=3,
            semester="Test Semester"
        )
        
        student1 = Student(
            first_name="Test",
            last_name="Student1",
            student_id="TS001",
            email="student1@example.com",
            major="Test Major",
            year=2
        )
        
        student2 = Student(
            first_name="Test",
            last_name="Student2",
            student_id="TS002",
            email="student2@example.com",
            major="Test Major",
            year=3
        )
        
        student3 = Student(
            first_name="Test",
            last_name="Student3",
            student_id="TS003",
            email="student3@example.com",
            major="Test Major",
            year=1
        )
        
        self.professor.add_course(course1)
        self.professor.add_course(course2)
        
        course1.add_student(student1)
        course1.add_student(student2)
        course2.add_student(student2)
        course2.add_student(student3)
        
        # student1 is in course1
        # student2 is in both course1 and course2
        # student3 is in course2
        # Total unique students: 3
        
        self.assertEqual(self.professor.get_student_count(), 4)

class TestProfessorController(unittest.TestCase):
    """Test cases for the ProfessorController."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.controller = ProfessorController()
        
        # Clear any sample data
        self.controller.professors = []
        self.controller.next_id = 1
        
        # Add a test professor
        self.test_professor = Professor(
            first_name="Test",
            last_name="Professor",
            department="Test Department",
            email="test@example.com",
            phone="555-123-4567",
            office="Test Building 101"
        )
        
        self.controller.add_professor(self.test_professor)
    
    def test_add_professor(self):
        """Test adding a professor."""
        new_professor = Professor(
            first_name="New",
            last_name="Professor",
            department="New Department",
            email="new@example.com",
            phone="555-987-6543",
            office="New Building 202"
        )
        
        result = self.controller.add_professor(new_professor)
        
        self.assertTrue(result)
        self.assertEqual(len(self.controller.professors), 2)
        self.assertEqual(new_professor.id, 2)
    
    def test_get_professor_by_id(self):
        """Test getting a professor by ID."""
        professor = self.controller.get_professor_by_id(1)
        
        self.assertIsNotNone(professor)
        self.assertEqual(professor.first_name, "Test")
        self.assertEqual(professor.last_name, "Professor")
    
    def test_update_professor(self):
        """Test updating a professor."""
        professor = self.controller.get_professor_by_id(1)
        
        updated_professor = Professor(
            id=professor.id,
            first_name="Updated",
            last_name="Professor",
            department=professor.department,
            email=professor.email,
            phone=professor.phone,
            office=professor.office
        )
        
        result = self.controller.update_professor(updated_professor)
        
        self.assertTrue(result)
        
        # Get the updated professor
        updated = self.controller.get_professor_by_id(1)
        self.assertEqual(updated.first_name, "Updated")
    
    def test_delete_professor(self):
        """Test deleting a professor."""
        result = self.controller.delete_professor(1)
        
        self.assertTrue(result)
        self.assertEqual(len(self.controller.professors), 0)
    
    def test_search_professors(self):
        """Test searching for professors."""
        # Add another professor for testing search
        another_professor = Professor(
            first_name="Another",
            last_name="Teacher",
            department="Test Department",
            email="another@example.com",
            phone="555-111-2222",
            office="Test Building 303"
        )
        
        self.controller.add_professor(another_professor)
        
        # Search by first name
        results = self.controller.search_professors("Test")
        self.assertEqual(len(results), 1)
        
        # Search by department
        results = self.controller.search_professors("test department")
        self.assertEqual(len(results), 2)
        
        # Search with no matches
        results = self.controller.search_professors("nonexistent")
        self.assertEqual(len(results), 0)

if __name__ == '__main__':
    unittest.main()