# Professor Management System

A comprehensive Python application for managing professor information, courses, and student grades.

## Features

- Professor profile management
- Course creation and management
- Student enrollment tracking
- Grade management and statistics
- Data visualization for course performance
- Export reports in various formats

## Installation

```bash
# Clone the repository
git clone https://github.com/tushargohil26/professor-management-system.git

# Navigate to the project directory
cd professor-management-system

# Install dependencies
pip install -r requirements.txt
```

## Usage

```bash
# Run the main application
python main.py
```

## Project Structure

- `main.py`: Entry point for the application
- `models/`: Contains all data models
- `controllers/`: Business logic and data processing
- `views/`: CLI interface components
- `utils/`: Helper functions and utilities
- `tests/`: Unit and integration tests