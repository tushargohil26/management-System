"""
Course Controller
Handles business logic for course-related operations.
"""

from typing import List, Optional, Dict, Any
from models.course import Course
from models.professor import Professor

class CourseController:
    """Controller for course-related operations."""
    
    def __init__(self):
        """Initialize the controller with an empty courses list for demo purposes."""
        self.courses: List[Course] = []
        self.next_id = 1
        
        # Add some sample data for demonstration
        self._add_sample_data()
    
    def _add_sample_data(self):
        """Add sample courses for demonstration."""
        sample_courses = [
            Course(
                code="CS101",
                title="Introduction to Computer Science",
                description="Fundamental concepts of programming and computer science.",
                credits=3,
                semester="Fall 2023"
            ),
            Course(
                code="MATH201",
                title="Calculus II",
                description="Integral calculus and applications.",
                credits=4,
                semester="Spring 2024"
            ),
            Course(
                code="PHYS150",
                title="Physics for Scientists and Engineers",
                description="Mechanics, waves, and thermodynamics with calculus applications.",
                credits=4,
                semester="Fall 2023"
            )
        ]
        
        for course in sample_courses:
            self.add_course(course)
    
    def get_all_courses(self) -> List[Course]:
        """Get all courses in the system."""
        return self.courses
    
    def get_course_by_id(self, course_id: int) -> Optional[Course]:
        """Get a course by its ID."""
        for course in self.courses:
            if course.id == course_id:
                return course
        return None
    
    def add_course(self, course: Course) -> bool:
        """Add a new course to the system."""
        try:
            course.id = self.next_id
            self.courses.append(course)
            self.next_id += 1
            return True
        except Exception:
            return False
    
    def update_course(self, course: Course) -> bool:
        """Update an existing course's information."""
        existing_course = self.get_course_by_id(course.id)
        if not existing_course:
            return False
        
        try:
            # Update the course's information
            index = self.courses.index(existing_course)
            
            # Preserve relationships
            course.professor = existing_course.professor
            course.students = existing_course.students
            
            self.courses[index] = course
            return True
        except Exception:
            return False
    
    def delete_course(self, course_id: int) -> bool:
        """Delete a course from the system."""
        course = self.get_course_by_id(course_id)
        if not course:
            return False
        
        try:
            # Remove the course from its professor
            if course.professor:
                course.professor.remove_course(course)
            
            # Remove the course from all students
            for student in course.students[:]:  # Create a copy to avoid modification during iteration
                course.remove_student(student)
            
            self.courses.remove(course)
            return True
        except Exception:
            return False
    
    def assign_professor(self, course_id: int, professor: Professor) -> bool:
        """Assign a professor to a course."""
        course = self.get_course_by_id(course_id)
        if not course:
            return False
        
        try:
            # If the course already has a professor, remove it from their courses
            if course.professor:
                course.professor.remove_course(course)
            
            # Assign the new professor
            professor.add_course(course)
            return True
        except Exception:
            return False
    
    def get_courses_by_semester(self, semester: str) -> List[Course]:
        """Get all courses for a specific semester."""
        return [c for c in self.courses if c.semester.lower() == semester.lower()]
    
    def search_courses(self, query: str) -> List[Course]:
        """Search for courses by code or title."""
        query = query.lower()
        results = []
        
        for course in self.courses:
            if (query in course.code.lower() or
                query in course.title.lower()):
                results.append(course)
        
        return results
    
    def get_course_statistics(self) -> Dict[str, Any]:
        """Get statistics about courses in the system."""
        if not self.courses:
            return {
                "total": 0,
                "by_semester": {},
                "avg_students": 0,
                "avg_credits": 0
            }
        
        semesters = {}
        total_students = 0
        total_credits = 0
        
        for course in self.courses:
            # Count semesters
            if course.semester in semesters:
                semesters[course.semester] += 1
            else:
                semesters[course.semester] = 1
            
            # Count students and credits
            total_students += len(course.students)
            total_credits += course.credits
        
        return {
            "total": len(self.courses),
            "by_semester": semesters,
            "avg_students": total_students / len(self.courses),
            "avg_credits": total_credits / len(self.courses)
        }