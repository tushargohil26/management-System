"""
Grade Controller
Handles business logic for grade-related operations.
"""

from typing import List, Optional, Dict, Any
from models.grade import Grade

class GradeController:
    """Controller for grade-related operations."""
    
    def __init__(self):
        """Initialize the controller with an empty grades list for demo purposes."""
        self.grades: List[Grade] = []
        self.next_id = 1
    
    def get_all_grades(self) -> List[Grade]:
        """Get all grades in the system."""
        return self.grades
    
    def get_grade(self, student_id: int, course_id: int) -> Optional[Grade]:
        """Get a grade for a specific student in a specific course."""
        for grade in self.grades:
            if grade.student_id == student_id and grade.course_id == course_id:
                return grade
        return None
    
    def get_grades_for_student(self, student_id: int) -> List[Grade]:
        """Get all grades for a specific student."""
        return [g for g in self.grades if g.student_id == student_id]
    
    def get_grades_for_course(self, course_id: int) -> List[Grade]:
        """Get all grades for a specific course."""
        return [g for g in self.grades if g.course_id == course_id]
    
    def add_grade(self, grade: Grade) -> bool:
        """Add a new grade to the system."""
        try:
            # Check if a grade already exists for this student and course
            existing_grade = self.get_grade(grade.student_id, grade.course_id)
            if existing_grade:
                # Update the existing grade instead of adding a new one
                return self.update_grade(grade)
            
            grade.id = self.next_id
            self.grades.append(grade)
            self.next_id += 1
            return True
        except Exception:
            return False
    
    def update_grade(self, grade: Grade) -> bool:
        """Update an existing grade."""
        existing_grade = self.get_grade(grade.student_id, grade.course_id)
        if not existing_grade:
            return False
        
        try:
            # Update the grade
            index = self.grades.index(existing_grade)
            grade.id = existing_grade.id  # Preserve the ID
            self.grades[index] = grade
            return True
        except Exception:
            return False
    
    def delete_grade(self, student_id: int, course_id: int) -> bool:
        """Delete a grade from the system."""
        grade = self.get_grade(student_id, course_id)
        if not grade:
            return False
        
        try:
            self.grades.remove(grade)
            return True
        except Exception:
            return False
    
    def get_grade_statistics(self, course_id: Optional[int] = None) -> Dict[str, Any]:
        """Get statistics about grades in the system."""
        grades_to_analyze = self.get_grades_for_course(course_id) if course_id else self.grades
        
        if not grades_to_analyze:
            return {
                "count": 0,
                "average": None,
                "median": None,
                "highest": None,
                "lowest": None,
                "passing_rate": None
            }
        
        values = [grade.value for grade in grades_to_analyze]
        values.sort()
        
        passing = sum(1 for v in values if v >= 60)  # Assuming 60 is passing
        
        return {
            "count": len(values),
            "average": sum(values) / len(values),
            "median": values[len(values) // 2],
            "highest": max(values),
            "lowest": min(values),
            "passing_rate": passing / len(values) * 100
        }
    
    def get_grade_distribution(self, course_id: Optional[int] = None) -> Dict[str, int]:
        """Get the distribution of letter grades."""
        grades_to_analyze = self.get_grades_for_course(course_id) if course_id else self.grades
        
        distribution = {
            "A": 0,
            "B": 0,
            "C": 0,
            "D": 0,
            "F": 0
        }
        
        for grade in grades_to_analyze:
            distribution[grade.get_letter_grade()] += 1
        
        return distribution