"""
Professor Controller
Handles business logic for professor-related operations.
"""

from typing import List, Optional, Dict, Any
from models.professor import Professor

class ProfessorController:
    """Controller for professor-related operations."""
    
    def __init__(self):
        """Initialize the controller with an empty professors list for demo purposes."""
        self.professors: List[Professor] = []
        self.next_id = 1
        
        # Add some sample data for demonstration
        self._add_sample_data()
    
    def _add_sample_data(self):
        """Add sample professors for demonstration."""
        sample_professors = [
            Professor(
                first_name="John",
                last_name="Smith",
                department="Computer Science",
                email="john.smith@university.edu",
                phone="555-123-4567",
                office="Science Building 301"
            ),
            Professor(
                first_name="Emily",
                last_name="Johnson",
                department="Mathematics",
                email="emily.johnson@university.edu",
                phone="555-987-6543",
                office="Math Building 204"
            ),
            Professor(
                first_name="Michael",
                last_name="Williams",
                department="Physics",
                email="michael.williams@university.edu",
                phone="555-456-7890",
                office="Science Building 105"
            )
        ]
        
        for prof in sample_professors:
            self.add_professor(prof)
    
    def get_all_professors(self) -> List[Professor]:
        """Get all professors in the system."""
        return self.professors
    
    def get_professor_by_id(self, professor_id: int) -> Optional[Professor]:
        """Get a professor by their ID."""
        for professor in self.professors:
            if professor.id == professor_id:
                return professor
        return None
    
    def add_professor(self, professor: Professor) -> bool:
        """Add a new professor to the system."""
        try:
            professor.id = self.next_id
            self.professors.append(professor)
            self.next_id += 1
            return True
        except Exception:
            return False
    
    def update_professor(self, professor: Professor) -> bool:
        """Update an existing professor's information."""
        existing_professor = self.get_professor_by_id(professor.id)
        if not existing_professor:
            return False
        
        try:
            # Update the professor's information
            index = self.professors.index(existing_professor)
            self.professors[index] = professor
            
            # Preserve the courses relationship
            professor.courses = existing_professor.courses
            
            return True
        except Exception:
            return False
    
    def delete_professor(self, professor_id: int) -> bool:
        """Delete a professor from the system."""
        professor = self.get_professor_by_id(professor_id)
        if not professor:
            return False
        
        try:
            self.professors.remove(professor)
            return True
        except Exception:
            return False
    
    def search_professors(self, query: str) -> List[Professor]:
        """Search for professors by name or department."""
        query = query.lower()
        results = []
        
        for professor in self.professors:
            if (query in professor.first_name.lower() or
                query in professor.last_name.lower() or
                query in professor.department.lower()):
                results.append(professor)
        
        return results
    
    def get_professors_by_department(self, department: str) -> List[Professor]:
        """Get all professors in a specific department."""
        return [p for p in self.professors if p.department.lower() == department.lower()]
    
    def get_professor_statistics(self) -> Dict[str, Any]:
        """Get statistics about professors in the system."""
        if not self.professors:
            return {
                "total": 0,
                "departments": {},
                "avg_courses": 0,
                "avg_students": 0
            }
        
        departments = {}
        total_courses = 0
        total_students = 0
        
        for professor in self.professors:
            # Count departments
            if professor.department in departments:
                departments[professor.department] += 1
            else:
                departments[professor.department] = 1
            
            # Count courses and students
            total_courses += len(professor.courses)
            total_students += professor.get_student_count()
        
        return {
            "total": len(self.professors),
            "departments": departments,
            "avg_courses": total_courses / len(self.professors) if self.professors else 0,
            "avg_students": total_students / len(self.professors) if self.professors else 0
        }