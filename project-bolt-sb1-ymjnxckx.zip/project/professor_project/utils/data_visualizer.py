"""
Data Visualizer
Utility for visualizing data from the system.
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import List, Dict, Any, Optional
import os

class DataVisualizer:
    """Utility for visualizing data from the system."""
    
    def __init__(self, output_dir: str = "reports"):
        """Initialize the visualizer with an output directory."""
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
    
    def plot_grade_distribution(self, distribution: Dict[str, int], course_name: Optional[str] = None) -> str:
        """
        Plot the distribution of letter grades.
        
        Args:
            distribution: Dictionary mapping letter grades to counts
            course_name: Optional name of the course for the title
            
        Returns:
            Path to the saved plot
        """
        plt.figure(figsize=(10, 6))
        
        grades = list(distribution.keys())
        counts = list(distribution.values())
        
        plt.bar(grades, counts, color=['green', 'blue', 'yellow', 'orange', 'red'])
        
        title = f"Grade Distribution{' for ' + course_name if course_name else ''}"
        plt.title(title)
        plt.xlabel("Letter Grade")
        plt.ylabel("Number of Students")
        
        # Add count labels on top of each bar
        for i, count in enumerate(counts):
            plt.text(i, count + 0.5, str(count), ha='center')
        
        filename = f"grade_distribution{'_' + course_name.replace(' ', '_') if course_name else ''}.png"
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath)
        plt.close()
        
        return filepath
    
    def plot_department_distribution(self, departments: Dict[str, int]) -> str:
        """
        Plot the distribution of professors by department.
        
        Args:
            departments: Dictionary mapping department names to counts
            
        Returns:
            Path to the saved plot
        """
        plt.figure(figsize=(12, 8))
        
        # Sort departments by count
        sorted_depts = sorted(departments.items(), key=lambda x: x[1], reverse=True)
        dept_names = [d[0] for d in sorted_depts]
        dept_counts = [d[1] for d in sorted_depts]
        
        # Create horizontal bar chart
        plt.barh(dept_names, dept_counts, color='skyblue')
        
        plt.title("Professors by Department")
        plt.xlabel("Number of Professors")
        plt.ylabel("Department")
        
        # Add count labels at the end of each bar
        for i, count in enumerate(dept_counts):
            plt.text(count + 0.1, i, str(count), va='center')
        
        plt.tight_layout()
        
        filepath = os.path.join(self.output_dir, "professors_by_department.png")
        plt.savefig(filepath)
        plt.close()
        
        return filepath
    
    def plot_course_enrollment(self, courses: List[Dict[str, Any]]) -> str:
        """
        Plot the enrollment numbers for different courses.
        
        Args:
            courses: List of dictionaries with 'title' and 'students' keys
            
        Returns:
            Path to the saved plot
        """
        plt.figure(figsize=(14, 8))
        
        # Sort courses by enrollment
        sorted_courses = sorted(courses, key=lambda x: x['students'], reverse=True)
        course_names = [c['title'] for c in sorted_courses]
        student_counts = [c['students'] for c in sorted_courses]
        
        # Truncate long course names
        course_names = [name[:20] + '...' if len(name) > 20 else name for name in course_names]
        
        # Create bar chart
        plt.bar(course_names, student_counts, color='lightgreen')
        
        plt.title("Course Enrollment")
        plt.xlabel("Course")
        plt.ylabel("Number of Students")
        plt.xticks(rotation=45, ha='right')
        
        # Add count labels on top of each bar
        for i, count in enumerate(student_counts):
            plt.text(i, count + 0.5, str(count), ha='center')
        
        plt.tight_layout()
        
        filepath = os.path.join(self.output_dir, "course_enrollment.png")
        plt.savefig(filepath)
        plt.close()
        
        return filepath
    
    def plot_grade_trends(self, semesters: List[str], averages: List[float], course_name: Optional[str] = None) -> str:
        """
        Plot the trend of average grades over semesters.
        
        Args:
            semesters: List of semester names
            averages: List of average grades for each semester
            course_name: Optional name of the course for the title
            
        Returns:
            Path to the saved plot
        """
        plt.figure(figsize=(12, 6))
        
        plt.plot(semesters, averages, marker='o', linestyle='-', color='blue')
        
        title = f"Grade Trends{' for ' + course_name if course_name else ''}"
        plt.title(title)
        plt.xlabel("Semester")
        plt.ylabel("Average Grade")
        
        # Add average labels at each point
        for i, avg in enumerate(averages):
            plt.text(i, avg + 1, f"{avg:.1f}", ha='center')
        
        # Add a horizontal line at the passing grade (60)
        plt.axhline(y=60, color='r', linestyle='--', alpha=0.7)
        plt.text(len(semesters) - 1, 61, "Passing Grade", color='r', ha='right')
        
        plt.ylim(0, 100)
        plt.grid(True, linestyle='--', alpha=0.7)
        
        filename = f"grade_trends{'_' + course_name.replace(' ', '_') if course_name else ''}.png"
        filepath = os.path.join(self.output_dir, filename)
        plt.savefig(filepath)
        plt.close()
        
        return filepath
    
    def plot_professor_workload(self, professors: List[Dict[str, Any]]) -> str:
        """
        Plot the workload (courses and students) for professors.
        
        Args:
            professors: List of dictionaries with 'name', 'courses', and 'students' keys
            
        Returns:
            Path to the saved plot
        """
        plt.figure(figsize=(14, 10))
        
        # Sort professors by number of students
        sorted_profs = sorted(professors, key=lambda x: x['students'], reverse=True)
        prof_names = [p['name'] for p in sorted_profs]
        course_counts = [p['courses'] for p in sorted_profs]
        student_counts = [p['students'] for p in sorted_profs]
        
        # Truncate long professor names
        prof_names = [name[:20] + '...' if len(name) > 20 else name for name in prof_names]
        
        # Create figure with two y-axes
        fig, ax1 = plt.subplots(figsize=(14, 8))
        ax2 = ax1.twinx()
        
        # Plot courses as bars
        bars = ax1.bar(prof_names, course_counts, color='skyblue', alpha=0.7, label='Courses')
        ax1.set_xlabel('Professor')
        ax1.set_ylabel('Number of Courses', color='blue')
        ax1.tick_params(axis='y', labelcolor='blue')
        
        # Plot students as a line
        line = ax2.plot(prof_names, student_counts, 'ro-', label='Students')
        ax2.set_ylabel('Number of Students', color='red')
        ax2.tick_params(axis='y', labelcolor='red')
        
        # Add a legend
        lines, labels = ax1.get_legend_handles_labels()
        lines2, labels2 = ax2.get_legend_handles_labels()
        ax2.legend(lines + lines2, labels + labels2, loc='upper right')
        
        plt.title('Professor Workload')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        filepath = os.path.join(self.output_dir, "professor_workload.png")
        plt.savefig(filepath)
        plt.close()
        
        return filepath