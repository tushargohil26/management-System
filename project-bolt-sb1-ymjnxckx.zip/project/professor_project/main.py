#!/usr/bin/env python3
"""
Professor Management System - Main Entry Point
Author: Tushar Gohil
GitHub: https://github.com/tushargohil26
"""

import os
import sys
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from typing import List, Dict, Optional

# Add the project directory to the path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from models.professor import Professor
from models.course import Course
from models.student import Student
from controllers.professor_controller import ProfessorController
from controllers.course_controller import CourseController
from controllers.grade_controller import GradeController
from utils.data_visualizer import DataVisualizer

console = Console()

def display_welcome_message():
    """Display a welcome message to the user."""
    console.print(Panel.fit(
        "[bold blue]Professor Management System[/bold blue]\n"
        "[italic]A comprehensive tool for managing academic information[/italic]",
        border_style="blue"
    ))

def display_menu() -> int:
    """Display the main menu and return the user's choice."""
    console.print("\n[bold]Main Menu:[/bold]")
    options = [
        "Manage Professors",
        "Manage Courses",
        "Manage Students",
        "Grade Management",
        "Generate Reports",
        "Data Visualization",
        "Exit"
    ]
    
    for i, option in enumerate(options, 1):
        console.print(f"  {i}. {option}")
    
    while True:
        try:
            choice = int(console.input("\n[bold]Enter your choice (1-7):[/bold] "))
            if 1 <= choice <= 7:
                return choice
            console.print("[bold red]Invalid choice. Please enter a number between 1 and 7.[/bold red]")
        except ValueError:
            console.print("[bold red]Please enter a valid number.[/bold red]")

def manage_professors(professor_controller: ProfessorController):
    """Handle professor management operations."""
    console.print(Panel.fit("[bold]Professor Management[/bold]", border_style="green"))
    
    options = [
        "List all professors",
        "Add a new professor",
        "Update professor information",
        "Delete a professor",
        "View professor details",
        "Return to main menu"
    ]
    
    for i, option in enumerate(options, 1):
        console.print(f"  {i}. {option}")
    
    choice = int(console.input("\n[bold]Enter your choice (1-6):[/bold] "))
    
    if choice == 1:
        professors = professor_controller.get_all_professors()
        display_professors(professors)
    elif choice == 2:
        add_new_professor(professor_controller)
    elif choice == 3:
        update_professor(professor_controller)
    elif choice == 4:
        delete_professor(professor_controller)
    elif choice == 5:
        view_professor_details(professor_controller)
    elif choice == 6:
        return
    else:
        console.print("[bold red]Invalid choice.[/bold red]")

def display_professors(professors: List[Professor]):
    """Display a list of professors in a table format."""
    if not professors:
        console.print("[italic]No professors found.[/italic]")
        return
    
    table = Table(title="Professors")
    table.add_column("ID", style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Department")
    table.add_column("Email")
    table.add_column("Courses", style="green")
    
    for prof in professors:
        table.add_row(
            str(prof.id),
            f"{prof.first_name} {prof.last_name}",
            prof.department,
            prof.email,
            str(len(prof.courses))
        )
    
    console.print(table)

def add_new_professor(professor_controller: ProfessorController):
    """Add a new professor to the system."""
    console.print("[bold]Add New Professor[/bold]")
    
    first_name = console.input("First Name: ")
    last_name = console.input("Last Name: ")
    department = console.input("Department: ")
    email = console.input("Email: ")
    phone = console.input("Phone (optional): ")
    office = console.input("Office Location: ")
    
    new_professor = Professor(
        first_name=first_name,
        last_name=last_name,
        department=department,
        email=email,
        phone=phone,
        office=office
    )
    
    result = professor_controller.add_professor(new_professor)
    if result:
        console.print("[bold green]Professor added successfully![/bold green]")
    else:
        console.print("[bold red]Failed to add professor.[/bold red]")

def update_professor(professor_controller: ProfessorController):
    """Update an existing professor's information."""
    professors = professor_controller.get_all_professors()
    display_professors(professors)
    
    if not professors:
        return
    
    prof_id = int(console.input("\nEnter the ID of the professor to update: "))
    professor = professor_controller.get_professor_by_id(prof_id)
    
    if not professor:
        console.print("[bold red]Professor not found.[/bold red]")
        return
    
    console.print(f"\n[bold]Updating Professor: {professor.first_name} {professor.last_name}[/bold]")
    console.print("[italic]Leave field empty to keep current value[/italic]")
    
    first_name = console.input(f"First Name [{professor.first_name}]: ") or professor.first_name
    last_name = console.input(f"Last Name [{professor.last_name}]: ") or professor.last_name
    department = console.input(f"Department [{professor.department}]: ") or professor.department
    email = console.input(f"Email [{professor.email}]: ") or professor.email
    phone = console.input(f"Phone [{professor.phone}]: ") or professor.phone
    office = console.input(f"Office Location [{professor.office}]: ") or professor.office
    
    updated_professor = Professor(
        id=professor.id,
        first_name=first_name,
        last_name=last_name,
        department=department,
        email=email,
        phone=phone,
        office=office
    )
    
    result = professor_controller.update_professor(updated_professor)
    if result:
        console.print("[bold green]Professor updated successfully![/bold green]")
    else:
        console.print("[bold red]Failed to update professor.[/bold red]")

def delete_professor(professor_controller: ProfessorController):
    """Delete a professor from the system."""
    professors = professor_controller.get_all_professors()
    display_professors(professors)
    
    if not professors:
        return
    
    prof_id = int(console.input("\nEnter the ID of the professor to delete: "))
    
    # Confirm deletion
    confirm = console.input(f"[bold red]Are you sure you want to delete this professor? (y/n):[/bold red] ")
    if confirm.lower() != 'y':
        console.print("Deletion cancelled.")
        return
    
    result = professor_controller.delete_professor(prof_id)
    if result:
        console.print("[bold green]Professor deleted successfully![/bold green]")
    else:
        console.print("[bold red]Failed to delete professor.[/bold red]")

def view_professor_details(professor_controller: ProfessorController):
    """View detailed information about a specific professor."""
    professors = professor_controller.get_all_professors()
    display_professors(professors)
    
    if not professors:
        return
    
    prof_id = int(console.input("\nEnter the ID of the professor to view: "))
    professor = professor_controller.get_professor_by_id(prof_id)
    
    if not professor:
        console.print("[bold red]Professor not found.[/bold red]")
        return
    
    console.print(Panel.fit(
        f"[bold]Professor Details: {professor.first_name} {professor.last_name}[/bold]\n\n"
        f"Department: {professor.department}\n"
        f"Email: {professor.email}\n"
        f"Phone: {professor.phone}\n"
        f"Office: {professor.office}\n\n"
        f"Courses: {len(professor.courses)}\n"
        f"Students: {sum(len(course.students) for course in professor.courses)}",
        border_style="green"
    ))
    
    if professor.courses:
        course_table = Table(title="Courses Taught")
        course_table.add_column("ID", style="dim")
        course_table.add_column("Course Code", style="bold")
        course_table.add_column("Title")
        course_table.add_column("Semester")
        course_table.add_column("Students", style="green")
        
        for course in professor.courses:
            course_table.add_row(
                str(course.id),
                course.code,
                course.title,
                course.semester,
                str(len(course.students))
            )
        
        console.print(course_table)

def main():
    """Main application entry point."""
    display_welcome_message()
    
    # Initialize controllers
    professor_controller = ProfessorController()
    course_controller = CourseController()
    grade_controller = GradeController()
    data_visualizer = DataVisualizer()
    
    while True:
        choice = display_menu()
        
        if choice == 1:
            manage_professors(professor_controller)
        elif choice == 2:
            # Manage courses (implementation similar to manage_professors)
            console.print("[italic]Course management functionality coming soon...[/italic]")
        elif choice == 3:
            # Manage students
            console.print("[italic]Student management functionality coming soon...[/italic]")
        elif choice == 4:
            # Grade management
            console.print("[italic]Grade management functionality coming soon...[/italic]")
        elif choice == 5:
            # Generate reports
            console.print("[italic]Report generation functionality coming soon...[/italic]")
        elif choice == 6:
            # Data visualization
            console.print("[italic]Data visualization functionality coming soon...[/italic]")
        elif choice == 7:
            console.print("[bold blue]Thank you for using the Professor Management System![/bold blue]")
            break

if __name__ == "__main__":
    main()