# Professor Project

This is a comprehensive Python application for managing professor information, courses, and student grades. The project is designed to showcase object-oriented programming principles, data management, and CLI interface design in Python.

## Project Structure

The project follows a Model-View-Controller (MVC) architecture:

- **Models**: Define the data structures for professors, courses, students, and grades
- **Controllers**: Handle business logic and data operations
- **Utils**: Provide helper functions like data visualization
- **Tests**: Include unit tests for models and controllers

## Features

- Professor profile management
- Course creation and management
- Student enrollment tracking
- Grade management and statistics
- Data visualization for course performance
- Export reports in various formats

## How to Use

1. Clone this repository to your local machine
2. Navigate to the `professor_project` directory
3. Run `python main.py` to start the application

## Adding to GitHub

To add this project to your GitHub repository:

```bash
# Navigate to the project directory
cd professor_project

# Initialize a git repository
git init

# Add all files to the repository
git add .

# Commit the changes
git commit -m "Initial commit of Professor Management System"

# Add your GitHub repository as a remote
git remote add origin https://github.com/tushargohil26/professor-management-system.git

# Push the code to GitHub
git push -u origin main
```

## Testing

Run the tests using the Python unittest module:

```bash
python -m unittest discover tests
```

## License

This project is licensed under the MIT License - see the LICENSE file for details.