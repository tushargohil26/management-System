import React, { useState, useEffect } from 'react';
import { Terminal } from 'lucide-react';

function App() {
  const [output, setOutput] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Simulate Python output
        const sampleOutput = [
          "Welcome to Professor Management System",
          "Loading modules...",
          "Initializing database...",
          "System ready!",
          "",
          "Main Menu:",
          "1. Manage Professors",
          "2. Manage Courses",
          "3. Manage Students",
          "4. Grade Management",
          "5. Generate Reports",
          "6. Data Visualization",
          "7. Exit"
        ];

        // Simulate loading with delays
        for (let i = 0; i < sampleOutput.length; i++) {
          await new Promise(resolve => setTimeout(resolve, 300));
          setOutput(prev => [...prev, sampleOutput[i]]);
        }
        setLoading(false);
      } catch (error) {
        console.error('Error:', error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Terminal className="w-8 h-8 text-green-400" />
          <h1 className="text-2xl font-bold">Professor Management System</h1>
        </div>
        
        <div className="bg-black rounded-lg p-6 font-mono">
          {loading && (
            <div className="animate-pulse text-green-400">
              Loading system...
            </div>
          )}
          
          {output.map((line, index) => (
            <div 
              key={index} 
              className={`${line === '' ? 'mb-4' : 'mb-1'} ${
                line.startsWith('Welcome') ? 'text-green-400 font-bold' :
                line.startsWith('Main Menu:') ? 'text-yellow-400 font-bold' :
                line.match(/^\d\./) ? 'text-blue-400' : 'text-gray-300'
              }`}
            >
              {line.startsWith('Welcome') && '> '}
              {line}
            </div>
          ))}
          
          {!loading && (
            <div className="mt-4 text-green-400 animate-blink">
              Enter your choice (1-7): _
            </div>
          )}
        </div>

        <div className="mt-6 text-gray-400 text-sm">
          <p>Project by: Tushar Gohil</p>
          <p>GitHub: <a href="https://github.com/tushargohil26" className="text-blue-400 hover:underline" target="_blank" rel="noopener noreferrer">tushargohil26</a></p>
        </div>
      </div>
    </div>
  );
}

export default App;